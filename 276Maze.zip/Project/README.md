CMPT 276 Group 25 - Ghost Run<a name="TOP"></a>
===================

- - - - 
# Description #

A arcade-style game that follows Friendly Ghost trying to collect keys to escape the Dark Spirit Maze. Players can collect Keys and Power Gems while avoiding the Dark Spirits that guard the maze and their Cursed Gems.

- - - - 
# How to Play #
- Users play as Friendly Ghost and has to traverse the randomly generated maze to escape
- Use W, A, S, D to move Friendly Ghost
- Go around the maze collecting all the keys to unlock the exit and win the game
- Green Power Gems give score while Red Cursed Gems take score
- Running into a Dark Spirit or getting a negative score gives a game over

- - - - 
# Prerequisites #
- Install InteliJ
- Java Development Kit 15 (JDK)
- JavaFX 15.0.1 (for JAR): https://gluonhq.com/download/javafx-15-0-1-sdk-armv6hf/

- - - - 
# How to Run #
1. Run InteliJ and open the project in InteliJ
2. In the Project Explorer navigate to: src > main > java > maze > Launcher
3. Right-click Launcher and click Run 'Launcher' 

- - - - 
# How to Build JAR #
1. Run InteliJ and open the project in InteliJ
2. Go to File > Project Structure... > Artifacts
3. Click the "+" at the top and select JAR > From modules and dependencies...
4. Set the Main Class to the Launcher class and click OK
5. Under Output Layout click the "+" and add File
6. Navigate to the JavaFX you downloaded as a prerequisite (should be called javafx-sdk-15.0.1)
7. Select all the files in the bin folder of JavaFX and click OK
8. Go to Build > Build Artifacts... and Build the Artifact you just created
9. Locate the JAR file you just compiled (default is in out/artifacts/<artifact name>)
10. Double-click to run the game
- - - - 
# How to Create Javadocs #
1. Run InteliJ and open the project in InteliJ
2. Go to Tools > Generate JavaDoc... set the Output directory
3. Click OK

- - - - 
# How to Run Tests #
1. Run InteliJ and open the project in InteliJ
2. In the Project Explorer navigate to: src > test > java > GameTest
3. Right-click GameTest and click Run 'GameTest'
