package maze;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * The class that is used to run the JavaFX application.
 */
public class App extends Application {
    // Used for generating the pre-made map
    String[][] initialMap = {
            {"W","W","W","W","W","W","W"},
            {"W","M","R","W","R","R","W"},
            {"W","R","E","E","E","R","L"},
            {"W","W","E","W","E","W","W"},
            {"W","K","E","E","K","R","W"},
            {"S","E","R","W","R","R","W"},
            {"W","W","W","W","W","W","W"}
    };
    //Board gameBoard = new Board(initialMap);

    boardView boardImage = boardView.getInstance();
    tutorialView tutorialImage = tutorialView.getInstance();

    /**
     * Starts the application.
     * @param stage The app's stage.
     */
    @Override
    public void start(Stage stage) {
        // Initialize the audio files
        Media soundLose = new Media(getClass().getResource("/audio/gameOver.mp3").toExternalForm());
        MediaPlayer playLose = new MediaPlayer(soundLose);

        Media soundWin = new Media(getClass().getResource("/audio/win.mp3").toExternalForm());
        MediaPlayer playWin = new MediaPlayer(soundWin);

        Media soundMove = new Media(getClass().getResource("/audio/move.mp3").toExternalForm());
        MediaPlayer playMove = new MediaPlayer(soundMove);

        Media soundKey = new Media(getClass().getResource("/audio/key.mp3").toExternalForm());
        MediaPlayer playKey = new MediaPlayer(soundKey);

        Media soundReward = new Media(getClass().getResource("/audio/reward.mp3").toExternalForm());
        MediaPlayer playReward = new MediaPlayer(soundReward);

        Media soundPunish = new Media(getClass().getResource("/audio/punishment.mp3").toExternalForm());
        MediaPlayer playPunish = new MediaPlayer(soundPunish);

        Media soundClick = new Media(getClass().getResource("/audio/click.mp3").toExternalForm());
        MediaPlayer playClick = new MediaPlayer(soundClick);

        // Initialize the images for the main menu
        Image title = new Image(getClass().getResourceAsStream("/sprites/title.png"));
        Image play = new Image(getClass().getResourceAsStream("/sprites/play.png"));
        Image tutorial = new Image(getClass().getResourceAsStream("/sprites/tutorial.png"));
        Image back = new Image(getClass().getResourceAsStream("/sprites/back.png"));
        Image mainmenu = new Image(getClass().getResourceAsStream("/sprites/restart.png"));

        ImageView titleImg = new ImageView(title);
        ImageView playImg = new ImageView(play);
        ImageView tutorialImg = new ImageView(tutorial);
        ImageView backImg = new ImageView(back);
        ImageView mainmenuImg = new ImageView(mainmenu);

        // Play Button Code
        Button playBtn = new Button();
        playBtn.setGraphic(playImg);
        playBtn.setStyle("-fx-background-color: transparent;");
        playBtn.setOnMouseEntered(e -> playBtn.setStyle("-fx-background-color: -fx-shadow-highlight-color, -fx-outer-border, -fx-inner-border, -fx-body-color;"));
        playBtn.setOnMouseExited((e -> playBtn.setStyle("-fx-background-color: transparent;")));

        // Tutorial Button Code
        Button tutorialBtn = new Button();
        tutorialBtn.setGraphic(tutorialImg);
        tutorialBtn.setStyle("-fx-background-color: transparent;");
        tutorialBtn.setOnMouseEntered(e -> tutorialBtn.setStyle("-fx-background-color: -fx-shadow-highlight-color, -fx-outer-border, -fx-inner-border, -fx-body-color;"));
        tutorialBtn.setOnMouseExited((e -> tutorialBtn.setStyle("-fx-background-color: transparent;")));

        // Back Button Code
        Button backBtn = new Button();
        backBtn.setGraphic(backImg);
        backBtn.setStyle("-fx-background-color: transparent;");
        backBtn.setOnMouseEntered(e -> backBtn.setStyle("-fx-background-color: -fx-shadow-highlight-color, -fx-outer-border, -fx-inner-border, -fx-body-color;"));
        backBtn.setOnMouseExited((e -> backBtn.setStyle("-fx-background-color: transparent;")));

        // Main Menu Button Code
        Button mainmenuBtn = new Button();
        mainmenuBtn.setGraphic(mainmenuImg);
        mainmenuBtn.setStyle("-fx-background-color: transparent;");
        mainmenuBtn.setOnMouseEntered(e -> mainmenuBtn.setStyle("-fx-background-color: -fx-shadow-highlight-color, -fx-outer-border, -fx-inner-border, -fx-body-color;"));
        mainmenuBtn.setOnMouseExited((e -> mainmenuBtn.setStyle("-fx-background-color: transparent;")));

        // Sets title of window and icon for taskbar app image
        stage.setTitle("Ghost Run");
        stage.getIcons().add(new Image(getClass().getResourceAsStream("/sprites/character.png")));

        // Sets Vertical Box container to be used for displaying visual elements
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30, 30, 30, 30));

        // Adds the main menu elements to the scene and then to a stage and displays it in the window
        root.getChildren().addAll(titleImg, playBtn, tutorialBtn);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

        // Event for when the tutorial button is clicked
        tutorialBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                playClick.stop();
                playClick.play();
                root.getChildren().clear();
                root.getChildren().addAll(tutorialImage.list, backBtn);
                stage.sizeToScene();
            }
        });

    // Event for when back button is clicked in tutorialView
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                playClick.stop();
                playClick.play();
                root.getChildren().clear();
                root.getChildren().addAll(titleImg, playBtn, tutorialBtn);
                stage.sizeToScene();
            }
        });

        // Event for when main menu button is clicked during gameplay
        mainmenuBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                playClick.stop();
                playClick.play();
                root.getChildren().clear();
                root.getChildren().addAll(titleImg, playBtn, tutorialBtn);
                root.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
                stage.sizeToScene();
            }
        });

        // Event for when the play button is clicked
        playBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                root.getChildren().clear();
                Game game = new Game(169);
                
                playClick.stop();
                playClick.play();
                 // New Vertical Box for storing the game info, such as score and keys remaining
                VBox info = new VBox();
                //info.setPadding(new Insets(30, 30, 30, 30));

                // Creating the labels for game stats
                Label score = new Label();
                score.setText("Score: " + Integer.toString(game.score));
                score.setFont(new Font("Calibri", 28));

                Label keys = new Label();
                keys.setText("Keys Left: " + Integer.toString(game.remainingKeys));
                keys.setFont(new Font("Calibri", 28));

                // New Horizontal Box for GUI buttons to restart the game and go back to main menu

                HBox gBtns = new HBox();
                gBtns.setPadding(new Insets(30, 30, 30, 30));

                // Sets regions for alignment
                Region tLeft = new Region();
                HBox.setHgrow(tLeft, Priority.ALWAYS);

                Region tRight = new Region();
                HBox.setHgrow(tRight, Priority.ALWAYS);

                // Adds the game info to the info container
                info.getChildren().addAll(score, keys);
                info.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));

                // Add GUI buttons to container

                gBtns.getChildren().addAll(info, tLeft, mainmenuBtn);
                gBtns.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));

                // Initializes the game grid to be displayed
                boardImage = new boardView();
                boardImage.createGrid(game.gameBoard);
                boardImage.update(game);

                // Resets the contents of the initial VBox and replaces it with the game
                root.getChildren().clear();
                root.setPadding(new Insets(0, 0, 0, 0));
                root.getChildren().addAll(gBtns, boardImage);
                stage.sizeToScene();
                root.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

                // Detection for key press, advances when a key is pressed
                scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
                    @Override
                    public void handle(KeyEvent keyEvent) {
                        if (!game.gameEnded) {
                            String code = keyEvent.getCode().toString();
                            // Moves the player based on the key pressed (Input validation built into movePlayer())
                            game.movePlayer(code);
                            if (game.moving) {
                                playMove.stop();
                                playMove.play();
                            }
                            if (game.curCell == "R") {
                                playReward.stop();
                                playReward.play();
                            }
                            else if (game.curCell == "K") {
                                playKey.stop();
                                playKey.play();
                            }
                            else if (game.curCell == "D") {
                                playPunish.stop();
                                playPunish.play();
                            }
                            // Updates the display with new board state
                            boardImage.update(game);
                            // Changes the game info
                            score.setText("Score: " + Integer.toString(game.score));
                            keys.setText("Keys Left: " + Integer.toString(game.remainingKeys));
                            // Checks the game state and displays a message if the game has ended
                            if (game.gameEnded && game.reachedEnd){
                                playWin.stop();
                                playWin.play();
                                keys.setText("You Won!");
                            }
                            else if (game.gameEnded && game.score < 0) {
                                playLose.stop();
                                playLose.play();
                                keys.setText("Game Over! You have a negative score.");
                            }
                            else if (game.gameEnded) {
                                playLose.stop();
                                playLose.play();
                                keys.setText("Game Over! You got hit by an enemy.");
                            }
                        }
                    }
                });
            }
        });
    }
    // Launches the app
    public static void main(String[] args) {
        launch();
    }
}
