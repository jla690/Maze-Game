package maze;
import java.lang.Math;
import java.util.Random;

/**
 * The Board class is the class that generates the map
 * the game is played on.
 */
public class Board {
    static Cell[] map;
    int len;
    public int rowLen; //size of each row, or just square root of len
    static int cPos;
    int[] specs;
    int keys;

    /**
     * The constructor that takes a 2D array of Strings and generates a map based on the input.
     * @param inputMap The array of Strings that generate a map.
     */
    public Board(String[][] inputMap) {
        int[] tmp = {0, 0, 0, 0, 0};
        rowLen = inputMap.length;
        len = inputMap.length*inputMap.length;
        map = new Cell[(int)Math.pow(rowLen, 2)];
        for (int i = 0; i < rowLen; i++) {
            for (int j = 0; j < rowLen; j++) {
                map[i * rowLen + j] = new Cell(inputMap[i][j], i * 10 + j);
                switch (inputMap[i][j]) {
                    case "S":
                        cPos = i * rowLen + j; break;
                    case "W":
                        tmp[0] += 1; break;
                    case "R":
                        tmp[1] += 1; break;
                    case "K":
                        tmp[2] += 1; break;
                    case "D":
                        tmp[3] += 1; break;
                    case "M":
                        tmp[4] += 1; break;
                }
            }
        }
        tmp[0] = tmp[0] - (rowLen*4 - 4);
        this.specs = tmp;
        this.keys = tmp[2];
        //System.out.println(tmp[0] + " " + tmp[1] + " " + tmp[2] + " " + tmp[3] + " " + tmp[4] + "\n");
    }

    /**
     * Default constructor for Board that generates a random 10 x 10 map.
     */
    public Board(){
        this(100);
    }

    /**
     * Default constructor for Board that generates a random len x len map.
     */
    public Board(int len){
        if(len != Math.round(Math.sqrt(len))*Math.round(Math.sqrt(len))){
            System.out.println("board size must be perfect square number");
            return;
        }

        this.len = len;
        rowLen = (int) Math.sqrt(len);
        map = new Cell[len];
        generateBorder();

        int[] specs = {20, 10, 4, 4, 3};
        
        this.specs = specs;
        keys = specs[2];
        randomizeBoard();
    }

    /**
     * Function that generates a map with walls and empty interior.
     */

    public void generateBorder(){
        for(int i = 0; i < rowLen; i++) {
            for (int j = 0; j < rowLen; j++) {
                if (i == 0 || i == rowLen - 1 || j == 0 || j == rowLen - 1) {
                    map[i * rowLen + j] = new Cell("W", i * rowLen + j);
                } else {
                    map[i * rowLen + j] = new Cell("E", i * rowLen + j);
                }
            }
        }
    }

    /**
     * Function that generates a map based on the array given.
     * It uses three helper functions so the function is less bloated
     *
     * This function accepts no parameters, but uses specs[] from the class variable.
     *              specs[0] is num of extra walls
     *              specs[1] is num of rewards
     *              specs[2] is num of keys
     *              specs[3] is num of debuffs
     *              specs[4] is num of enemies
     */

    public void randomizeBoard(){
        rbMakeWall();
        rbMakeEntity();
        rbMakeDoor();
    }

    private void rbMakeWall() {

        int[] wallTracker = new int[len]; //used to help generate random walls

        for(int i = 0; i < len; i++){
            wallTracker[i] = i;
        }

        randomizeArray(wallTracker);

        //generating walls requires many checks because we should make sure that any non wall square can be accessed
        int skipped = 0; //number of skipped walls due to too many adjacent walls
        for (int i = 0; i < specs[0] + skipped; i++) { //randomizes walls
            try {
                if (!getSymbolAt(wallTracker[i]).equals("W")) { //making sure we're not checking a border
                    StringBuilder adjCells = new StringBuilder();

                    adjCells.append(getSymbolAt(wallTracker[i] + 1)); //right
                    adjCells.append(getSymbolAt(wallTracker[i] + 1)); //left
                    adjCells.append(getSymbolAt(wallTracker[i] + rowLen)); //down
                    adjCells.append(getSymbolAt(wallTracker[i] - rowLen)); //up
                    adjCells.append(getSymbolAt(wallTracker[i] + 1 + rowLen)); //down right
                    adjCells.append(getSymbolAt(wallTracker[i] - 1 + rowLen)); //down left
                    adjCells.append(getSymbolAt(wallTracker[i] + 1 - rowLen)); //top right
                    adjCells.append(getSymbolAt(wallTracker[i] - 1 - rowLen)); //top left

                    long count = adjCells.chars().filter(ch -> ch == 'W').count(); //checks number of walls in adjCells

                    if (count > 1) {
                        skipped++;

                    } else {
                        map[wallTracker[i]] = new Cell("W", wallTracker[i]);
                    }
                } else{
                    skipped++;
                }
            } catch (Exception ArrayIndexOutOfBoundsException) {
                System.out.println("Too many walls! Try a lower amount");
                System.exit(3);
            }
        }
    }

    private void rbMakeEntity(){

        int[] otherTracker = new int[len - specs[0]]; //tracks positions of attributes other than extra walls

        for(int i = 0; i < otherTracker.length; i++){
            otherTracker[i] = i;
        }

        randomizeArray(otherTracker);

        //now we add in the other parts of the board. There are no special rules on placements
        //other than these cannot be placed on the border and there shouldn't be more than the number of empty spaces

        int totalSpecial = 0;

        for(int i = 1; i < 5; i++){
            totalSpecial+= specs[i];
        }

        if(totalSpecial > otherTracker.length){
            System.out.println("Too many extras! Try a lower amount");
            return;
        }

        int skipped = 0;
        for(int i = 0; i < specs[1] + skipped; i++) {
            if(!getSymbolAt(otherTracker[i]).equals("W"))
                map[otherTracker[i]] = new Cell("R", otherTracker[i]);
            else
                skipped++;
        }
        for(int i = specs[1] + skipped; i < specs[1] + specs[2] + skipped; i++) {
            if(!getSymbolAt(otherTracker[i]).equals("W"))
                map[otherTracker[i]] = new Cell("K", otherTracker[i]);
            else
                skipped++;
        }
        for(int i = specs[1] + specs[2] + skipped; i < specs[1] + specs[2] + specs[3] + skipped; i++) {
            if(!getSymbolAt(otherTracker[i]).equals("W"))
                map[otherTracker[i]] = new Cell("D", otherTracker[i]);
            else
                skipped++;
        }
        for(int i = specs[1] + specs[2] + specs[3] + skipped; i < specs[1] + specs[2] + specs[3]+ specs[4] + skipped; i++) {
            if(!getSymbolAt(otherTracker[i]).equals("W"))
                map[otherTracker[i]] = new Cell("M", otherTracker[i]);
            else
                skipped++;
        }
    }

    private void rbMakeDoor(){
        //for readability, i added the start/end location generation in a different subsection
        //the start/end location should be on a border, but not a corner.

        int[] enterExits = new int[rowLen*4-8];
        int i,j;
        int k = 0;

        for(i = 1; i < rowLen - 1; i++){
            enterExits[k++] = i;
            enterExits[k++] = i + len - rowLen;
        }

        for(j = rowLen + 1; j < len - rowLen; j += rowLen){
            enterExits[k++] = j - 1;
            enterExits[k++] = j + rowLen - 2;
        }

        randomizeArray(enterExits);

        map[enterExits[0]] = new Cell("S", enterExits[0]); //entrance
        map[enterExits[1]] = new Cell("L", enterExits[1]); //exit
        keys = specs[2];
        cPos = enterExits[0];

    }

    /**
     * Function that finds a position that is empty.
     * @param inputMap A array of Cells that is used for the function.
     * @param len The side length of the map.
     * @return A empty position.
     */
    public int random(Cell[] inputMap, int len) {
        int size = (int)Math.pow(len,2);
        int startingPos = 0;
        while (!inputMap[startingPos].symbol.equals("E")){
            startingPos = (int) (Math.random() * (size-1));
        }
        return startingPos;
    }


    /**
     * Function to print the current map.
     */
    public void print() {
        for (int i = 0; i < rowLen; i++) {
            StringBuilder temp = new StringBuilder();
            for (int j = 0; j < rowLen; j++) {
                if ((i * rowLen + j) == cPos)
                    temp.append("C ");
                else if (map[i * rowLen + j].symbol.equals("W"))
                    temp.append("# ");
                else if (map[i * rowLen + j].symbol.equals("E"))
                    temp.append("  ");
                else
                    temp.append(map[i * rowLen + j].symbol).append(" ");
            }
            System.out.println(temp);
        }
    }

        /**
         * Function to swap two cells in the current map using the cells themselves.
         * @param c1 The first of the two cells to be swapped.
         * @param c2 The second of the two cells to be swapped.
         */
    public static void swap(Cell c1,Cell c2){
        String temp=c1.symbol;
        c1.symbol=c2.symbol;
        c2.symbol=temp;
    }

    /**
     * Function to swap two cells in the current map using positions.
     * @param pos1 The first position of the two cells to be swapped.
     * @param pos2 The second position of the two cells to be swapped.
     */
    public static void swap(int pos1, int pos2){
        swap(map[pos1], map[pos2]);
    }

    /**
     * Function to get the symbol from the cell at a position.
     * @param pos The position of the cell to get a symbol from.
     * @return The symbol of the specified cell.
     */
    public static String getSymbolAt(int pos){
        if (pos < 0 || pos >= map.length)
            return "W";
        return map[pos].getSymbol();
    }

    /**
     * Function to randomize the array (int).
     * @param arr The array of ints to randomize.
     */
    public static void randomizeArray(int[] arr){
        int len=arr.length;
        for(int i=0;i<len;i++){
            Random random =new Random();
            int a=random.nextInt(len);
            int temp=arr[i];
            arr[i]=arr[a];
            arr[a]=temp;
        }
    }

    /**
     * Function to randomize the array (String).
     * @param arr The array of Strings to randomize.
     */
    public void randomizeArray(String[] arr){
        int len=arr.length;
        for(int i=0;i<len;i++){
            Random random =new Random();
            int a=random.nextInt(len);
            String temp=arr[i];
            arr[i]=arr[a];
            arr[a]=temp;
        }
    }

    /**
     * Function to get an array with all the enemy positions.
     * @return An array with the positions of the enemy characters.
     */
    public int[] getEnemyPosition(){

        int[] enemyPosition = new int[specs[4]];

        int i, j, k = 0;

        for(i = 0; i < Math.sqrt(len); i++){
            for(j = 0; j < Math.sqrt(len); j++){
                if(getSymbolAt(i * rowLen + j).equals("M")) {
                    enemyPosition[k] = i * rowLen + j;
                    k++;
                }
            }
        }

        return enemyPosition;
    }

}
