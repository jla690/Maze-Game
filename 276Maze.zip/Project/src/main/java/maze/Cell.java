package maze;

/**
 * Class that stores the symbols and positions of the board, used in Board map
 */
public class Cell {
    String symbol;
    int position;

    /**
     * Constructor to create a cell from an input array using position
     * @param cellType symbol in position
     * @param position position to store
     */
    public Cell(String cellType, int position){
        this.position = position;

        if(cellType.equals("W") || cellType.equals("R") || cellType.equals("M") || cellType.equals("K") || cellType.equals("D") || cellType.equals("S") || cellType.equals("L"))
            this.symbol = cellType;
        else
            this.symbol = "E";
    }

    /**
     * getter for position
     * @return cell position
     */
    public int getPosition() {
        return position;
    }

    /**
     * getter for symbol
     * @return cell symbol
     */
    public String getSymbol() {
        return symbol;
    }
}
