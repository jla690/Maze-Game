package maze;

import java.util.Scanner; //used for console UI, will be replaced later
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.io.File;

/**
 * Class for game logic and entity movement
 */
public class Game {
    public Board gameBoard;
    public int cPos;
    public int[] enemyPosition;
    public int score;
    public int lives;
    int currentTick;
    public int remainingKeys;
    String curCell;
    boolean moving = false;
    public boolean gameEnded = false;
    public boolean reachedEnd = false;
    int rowLength; //used for calculations
    int difficulty; //may not be implemented

    /**
     * initializes variables when game is started
     * @param cPos character position
     * @param enemyPosition array of enemy positions
     */
    Game(int cPos, int[] enemyPosition){
        score = 0;
        lives = 1;
        currentTick = 0;
        this.cPos = cPos;
        this.enemyPosition = enemyPosition;
    }

    /**
     * Default constructor.
     */
    public Game(){
        startGame();
        //inGame();
    }

    /**
     * Constructor to create a maze of specified length.
     * @param len The side length of the maze.
     */
    public Game(int len){
        startGame(len);
        //inGame();
    }

    /**
     * Constructor to create a maze with a map layout.
     * @param board The board to be loaded into the game.
     */
    public Game(Board board){
        startGame(board);
        //inGame();
    }

    /**
     * Sets the predefined conditions for a game with a random maze.
     */
    private void startGame() {
        score = 0;
        lives = 1;
        currentTick = 0;

        gameBoard = new Board();

        cPos = gameBoard.cPos;
        enemyPosition = gameBoard.getEnemyPosition();
        rowLength = gameBoard.rowLen;
        remainingKeys = gameBoard.keys;
    }

    /**
     * Sets the predefined conditions for a game with a maze of specified length.
     * @param len The side length of the maze.
     */
    private void startGame(int len) {
        score = 0;
        lives = 1;
        currentTick = 0;

        gameBoard = new Board(len);

        cPos = gameBoard.cPos;
        enemyPosition = gameBoard.getEnemyPosition();
        rowLength = gameBoard.rowLen;
        remainingKeys = gameBoard.keys;
    }

    /**
     * Sets the predefined conditions for a game with a maze from a map layout.
     * @param board The board to be loaded into the game.
     */
    private void startGame(Board board) {
        score = 0;
        lives = 1;
        currentTick = 0;

        gameBoard = board;

        cPos = gameBoard.cPos;
        enemyPosition = gameBoard.getEnemyPosition();
        rowLength = gameBoard.rowLen;
        remainingKeys = gameBoard.keys;
    }

    /**
     * Game loop that gets user input and displays the score and current map state while game is not over.
     */
    public void inGame(){
        gameBoard.print();
        while(!endGame()){
            movePlayer(Inputs.getInput());
            System.out.println("Score: " + score);
            gameBoard.print();
        }

        System.out.println("player quit game. terminating app");
    }

    /**
     * Checks to see whether the conditions for game over have been met.
     * @return Boolean value for if the game is over or not.
     */
    private boolean endGame() {

        if(remainingKeys == 0 && lives > 0 && score >=0 && reachedEnd) {
            System.out.println("Congrats! You won!");
            gameEnded = true;
            return true;
        }
        else if (lives <= 0){
            System.out.println("Lost: You ran of lives :(");
            gameEnded = true;
            return true;
        }
        else if (score < 0){
            System.out.println("Lost: Your score went negative :(");
            gameEnded = true;
            return true;
        }
        else {
            gameEnded = false;
            return false;
        }

        //Scanner scanner = new Scanner(System.in);

        /*System.out.println("Play again? (y)");
        String choice = scanner.nextLine();

        if(choice.equalsIgnoreCase("y")){
            startGame();
            return false;
        }*/
    }

    /**
     * Takes in keyboard input and checks if move is valid
     * @param move Player input
     */
    public void movePlayer(String move) { //takes in keyboard key input and moves player,
        //System.out.println("Key Pressed: " + move);
        move = move.toLowerCase(); // change to lowercase
        switch (move) {
            case "w":
                checkMove(Board.getSymbolAt(cPos - rowLength), cPos - rowLength); //north case
                moving = true;
                break;
            case "d":
                checkMove(Board.getSymbolAt(cPos + 1), cPos + 1); //east case
                moving = true;
                break;
            case "s":
                checkMove(Board.getSymbolAt(cPos + rowLength), cPos + rowLength); //south case
                moving = true;
                break;
            case "a":
                checkMove(Board.getSymbolAt(cPos - 1), cPos - 1); //west case
                moving = true;
                break;
            default:
                System.out.println("invalid input detected. Please try again");
                moving = false;
                return;
        }
        System.out.println("Remaining Keys: " + remainingKeys);
        System.out.println("Lives: " + lives);
        System.out.println("Points: " + score + "\n");
        checkEnemyCollision();
        moveEnemy();
        currentTick++;
        checkCollision();
        checkEnemyCollision();
    }

    /**
     * Checks to see if the space the main character is on is a special cell.
     */
    public void checkCollision(){
        String symbol = Board.getSymbolAt(cPos);

        switch (symbol) {
            case "R":
                curCell = "R";
                changeScore(50);
                Board.map[cPos] = new Cell("E", cPos);
                break;
            case "K":
                curCell = "K";
                Board.map[cPos] = new Cell("E", cPos);
                remainingKeys--;
                break;
            case "D":
                curCell = "D";
                changeScore(-100);
                Board.map[cPos] = new Cell("E", cPos);
                endGame();
                break;
            case "L":
                if (remainingKeys == 0) {
                    reachedEnd = true;
                    endGame();
                    break;
                }
                System.out.println("Get more keys: " + remainingKeys);
                break;
            default:
                curCell = "E";
        }
    }

    /**
     * Checks if enemy is in a space and handles the collision
     */
    private void checkEnemyCollision() {
        String symbol = Board.getSymbolAt(cPos);
        if (symbol == "M") {
            lives--;
            endGame();
        }
    }

    /**
     * Checks if move is valid and handles it accordingly
     * @param symbol Symbol of cell
     * @param newPos Potential new position
     */
    public void checkMove(String symbol, int newPos) {
        int oldPos = cPos;
        if (!symbol.equals("W") && !((Board.getSymbolAt(oldPos).equals("S") && symbol.equals("L")) || (Board.getSymbolAt(oldPos).equals("L") && symbol.equals("S")))) {
            cPos = newPos;
            Board.cPos = newPos;
        }
    }

    /**
     * Moves enemy randomly according to randomDirection()
     */
        public void moveEnemy(){
        int direction = 0;

        /*for(int i = 0; i < enemyPosition.length; i++){
            System.out.println(enemyPosition[i]);
        }*/

        for(int i= 0; i < enemyPosition.length; i++) {

            int choice = 0;
            int[] randomDirection = randomDirection();
            while (choice < 4) { //this loop checks for a wall. if there is a wall, enemy goes in a different direction
                //also checks for player/enemy collision
                direction = randomDirection[choice];
                if(Board.getSymbolAt(enemyPosition[i] + direction).equals("C")) {
                    lives--;
                    return;
                } else if(!Board.getSymbolAt(enemyPosition[i] + direction).equals("W") && !Board.getSymbolAt(enemyPosition[i] + direction).equals("M") && !Board.getSymbolAt(enemyPosition[i] + direction).equals("L") && !Board.getSymbolAt(enemyPosition[i] + direction).equals("S"))
                    break;
                choice++;
            }
            Board.swap(enemyPosition[i], enemyPosition[i] + direction); //switches contents of these two cells
            enemyPosition[i] = enemyPosition[i] + direction; //updates the location of enemy position
        }
    }

    /**
     * Finds a random direction for enemy to move in
     * @return returns random direction
     */
    public int[] randomDirection(){
        int[] directions = {1, -1, rowLength, -rowLength};
        Board.randomizeArray(directions);

        return directions;
    }

    /**
     * Function that changes the player's score.
     * @param change An integer to change the score by.
     */
    public void changeScore(int change){
        score += change;

        if(score <= 0){//score is zero or negative, indicating a game over
            //call endgame function, with parameter "Score is zero or negative"
        }
    }
}
