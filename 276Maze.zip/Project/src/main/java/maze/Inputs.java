package maze;

import java.util.Scanner;

/**
 * Class for getting keyboard input.
 */
public class Inputs {
    /**
     * Default constructor
     */
    public Inputs() {

    }
    /**
     * Function that gets char input and returns it.
     * @return The key pressed in char.
     */
    public static String getInput() {
        Scanner scan = new Scanner(System.in);
        return Character.toString(scan.next().charAt(0));
    }
}
