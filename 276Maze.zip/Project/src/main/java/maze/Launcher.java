package maze;

/**
 * Used for compilation, used to launch the application
 * Set this as your main class when compiling
 */
public class Launcher {
    public static void main(String[] args) {
        App.main(args);
    }
}
