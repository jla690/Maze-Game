package maze;

/**
 * Used for command line testing purposes. Run App for the game.
 */
public class Main {
    public static void main(String[] args) {
        String[][] initialMap = {
                {"W","W","W","W","W","W","W"},
                {"W","M","R","W","R","R","W"},
                {"W","R","E","E","E","R","L"},
                {"W","W","E","W","E","W","W"},
                {"W","K","E","E","K","R","W"},
                {"S","E","R","W","R","R","W"},
                {"W","W","W","W","W","W","W"}
        };

        Board gameBoard = new Board(initialMap);
        gameBoard.print();
        Game game = new Game(gameBoard);
        //new Game(100);
    }
}
