package maze;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Class that controls the ImageView of the board
 */
public class boardView extends Group {

    private static boardView single_instance = null;

    public final static double CELL_WIDTH = 64;

    public ImageView[][] mazeGrid;
    private final Image character;
    private final Image enemy;
    private final Image key;
    private final Image point;
    private final Image wall;
    private final Image debuff;
    private final Image lock;

    /**
     * Initializes values of image variables as corresponding sprites
     */
    public boardView() {
        this.character = new Image(getClass().getResourceAsStream("/sprites/character.png"));
        this.enemy = new Image(getClass().getResourceAsStream("/sprites/enemy.png"));
        this.key = new Image(getClass().getResourceAsStream("/sprites/key.png"));
        this.point = new Image(getClass().getResourceAsStream("/sprites/point.png"));
        this.wall = new Image(getClass().getResourceAsStream("/sprites/wall.png"));
        this.debuff = new Image(getClass().getResourceAsStream("/sprites/debuff.png"));
        this.lock = new Image(getClass().getResourceAsStream("/sprites/lock.png"));
    }

    /**
     * Singleton implementation to enforce at most one boardView is created
     * @return Returns the boardView instance if it exists, otherwise it creates a new one and returns it
     */
    public static boardView getInstance() {
        if (single_instance == null)
            single_instance = new boardView();
        return single_instance;
    }

    /**
     * Creates the empty ImageView grid.
     * @param maze The board that will be used later.
     */
    public void createGrid(Board maze) {
        int rowLen = maze.rowLen;
        this.mazeGrid = new ImageView[rowLen][rowLen];
        for (int i = 0; i < rowLen; i++) {
            for (int j = 0; j < rowLen; j++) {
                ImageView imageView = new ImageView();
                imageView.setX(j * CELL_WIDTH);
                imageView.setY(i * CELL_WIDTH);
                imageView.setFitWidth(CELL_WIDTH);
                imageView.setFitHeight(CELL_WIDTH);
                this.mazeGrid[i][j] = imageView;
                this.getChildren().add(imageView);
            }
        }
    }

    /**
     * Updates the view with images based on the cell symbol.
     * @param game The game instance that should be loaded.
     */
    public void update(Game game) {
        int rowLen = game.gameBoard.rowLen;
        for (int i = 0; i < rowLen; i++) {
            for (int j = 0; j < rowLen; j++) {
                this.mazeGrid[i][j].setImage(null);
                if ((i * rowLen + j) == Board.cPos && !Board.map[i * rowLen + j].symbol.equals("M"))
                    this.mazeGrid[i][j].setImage(this.character);
                else if (Board.map[i * rowLen + j].symbol.equals("W"))
                    this.mazeGrid[i][j].setImage(this.wall);
                else if (Board.map[i * rowLen + j].symbol.equals("M"))
                    this.mazeGrid[i][j].setImage(this.enemy);
                else if (Board.map[i * rowLen + j].symbol.equals("K"))
                    this.mazeGrid[i][j].setImage(this.key);
                else if (Board.map[i * rowLen + j].symbol.equals("D"))
                    this.mazeGrid[i][j].setImage(this.debuff);
                else if (Board.map[i * rowLen + j].symbol.equals("R"))
                    this.mazeGrid[i][j].setImage(this.point);
                else if (Board.map[i * rowLen + j].symbol.equals("L") && game.remainingKeys > 0)
                    this.mazeGrid[i][j].setImage(this.lock);
                else
                    this.mazeGrid[i][j].setImage(null);
            }
        }
    }
}

