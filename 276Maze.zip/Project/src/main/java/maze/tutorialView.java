package maze;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class tutorialView extends Group {

    private static tutorialView single_instance = null;

    public VBox list;
    private final Image character;
    private final Image enemy;
    private final Image key;
    private final Image point;
    private final Image wall;
    private final Image debuff;
    private final Image lock;

    /**
     * Singleton implementation to enforce at most one tutorialView is created
     * @return Returns the tutorialView instance if it exists, otherwise it creates a new one and returns it
     */
    public static tutorialView getInstance() {
        if (single_instance == null)
            single_instance = new tutorialView();
        return single_instance;
    }

    public tutorialView() {
        this.character = new Image(getClass().getResourceAsStream("/sprites/character.png"));
        this.enemy = new Image(getClass().getResourceAsStream("/sprites/enemy.png"));
        this.key = new Image(getClass().getResourceAsStream("/sprites/key.png"));
        this.point = new Image(getClass().getResourceAsStream("/sprites/point.png"));
        this.wall = new Image(getClass().getResourceAsStream("/sprites/wall.png"));
        this.debuff = new Image(getClass().getResourceAsStream("/sprites/debuff.png"));
        this.lock = new Image(getClass().getResourceAsStream("/sprites/lock.png"));

        list = new VBox();

        // Objective
        Label objectiveInfo = new Label();
        objectiveInfo.setText("Objective: To collect all the keys and reach the exit.");
        objectiveInfo.setFont(new Font("Calibri", 40));
        objectiveInfo.setPadding(new Insets(10, 10, 10, 10));

        // Main character info
        HBox characterBox = new HBox();
        ImageView characterImg = new ImageView();
        characterImg.setImage(character);
        Label characterInfo = new Label();
        characterInfo.setText("Friendly Ghost - Press W, A, S, D to move.");
        characterInfo.setFont(new Font("Calibri", 30));
        characterInfo.setPadding(new Insets(10, 10, 10, 50));
        characterBox.getChildren().addAll(characterImg, characterInfo);
        characterBox.setPadding(new Insets(10, 10, 10, 30));

        // Enemy info
        HBox enemyBox = new HBox();
        ImageView enemyImg = new ImageView();
        enemyImg.setImage(enemy);
        Label enemyInfo = new Label();
        enemyInfo.setText("Dark Spirit - Avoid them at all costs!");
        enemyInfo.setFont(new Font("Calibri", 30));
        enemyInfo.setPadding(new Insets(10, 10, 10, 50));
        enemyBox.getChildren().addAll(enemyImg, enemyInfo);
        enemyBox.setPadding(new Insets(10, 10, 10, 30));

        // Key info
        HBox keyBox = new HBox();
        ImageView keyImg = new ImageView();
        keyImg.setImage(key);
        Label keyInfo = new Label();
        keyInfo.setText("Key - Collect them all to escape.");
        keyInfo.setFont(new Font("Calibri", 30));
        keyInfo.setPadding(new Insets(10, 10, 10, 50));
        keyBox.getChildren().addAll(keyImg, keyInfo);
        keyBox.setPadding(new Insets(10, 10, 10, 30));

        // Point info
        HBox pointBox = new HBox();
        ImageView pointImg = new ImageView();
        pointImg.setImage(point);
        Label pointInfo = new Label();
        pointInfo.setText("Power Gem - They increase your score by 50.");
        pointInfo.setFont(new Font("Calibri", 30));
        pointInfo.setPadding(new Insets(10, 10, 10, 50));
        pointBox.getChildren().addAll(pointImg, pointInfo);
        pointBox.setPadding(new Insets(10, 10, 10, 30));

        // Debuff info
        HBox debuffBox = new HBox();
        ImageView debuffImg = new ImageView();
        debuffImg.setImage(debuff);
        Label debuffInfo = new Label();
        debuffInfo.setText("Cursed Gem - They decrease your score by 100.");
        debuffInfo.setFont(new Font("Calibri", 30));
        debuffInfo.setPadding(new Insets(10, 10, 10, 50));
        debuffBox.getChildren().addAll(debuffImg, debuffInfo);
        debuffBox.setPadding(new Insets(10, 10, 10, 30));

        // Wall info
        HBox wallBox = new HBox();
        ImageView wallImg = new ImageView();
        wallImg.setImage(wall);
        Label wallInfo = new Label();
        wallInfo.setText("Barrier - A wall that blocks your path.");
        wallInfo.setFont(new Font("Calibri", 30));
        wallInfo.setPadding(new Insets(10, 10, 10, 50));
        wallBox.getChildren().addAll(wallImg, wallInfo);
        wallBox.setPadding(new Insets(10, 10, 10, 30));

        // Lock info
        HBox lockBox = new HBox();
        ImageView lockImg = new ImageView();
        lockImg.setImage(lock);
        Label lockInfo = new Label();
        lockInfo.setText("Exit Lock - Locks the exit if you don't have all the keys.");
        lockInfo.setFont(new Font("Calibri", 30));
        lockInfo.setPadding(new Insets(10, 10, 10, 50));
        lockBox.getChildren().addAll(lockImg, lockInfo);
        lockBox.setPadding(new Insets(10, 10, 10, 30));

        list.getChildren().addAll(objectiveInfo, characterBox, enemyBox, keyBox, pointBox, debuffBox, wallBox, lockBox);
    }
}
