module maze {
    requires javafx.controls;
    requires javafx.media;
    exports maze;
}