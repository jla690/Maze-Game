/**
 * The package with the maze game implementation.
 */
package maze;
