import static org.junit.jupiter.api.Assertions.assertEquals;

import maze.Board;
import maze.Game;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;

import java.util.Arrays;


class GameTest {
    String[][] testmap1 = {
            {"W", "W", "W"},
            {"R", "S", "K"},
            {"W", "D", "W"}
    };
    String[][] enemymap = {
            {"E","E","E"},
            {"M","S","M"},
            {"E","E","E"}
    };
    String[][] lockmap = {
            {"W","W","W"},
            {"K","S","L"},
            {"W","W","W"}
    };
    String[][] winmap = {
            {"W","S","W"},
            {"W","K","L"},
            {"W","W","W"}
    };
    String[][] emptymap = {
            {"E","E","E"},
            {"E","S","E"},
            {"E","E","E"}
    };

    // Creates random instances
    @RepeatedTest(5)
    @DisplayName("Generating random map")
    public void createRandom() {
        Game maze = new Game(169);
        Assertions.assertEquals(13, maze.gameBoard.rowLen);
        maze.gameBoard.print();
    }

    @Test
    @DisplayName("Tests key collect")
    public void keyTest() {
        Board board1 = new Board(testmap1);
        Game game1 = new Game(board1);
        game1.movePlayer("D");
        Assertions.assertEquals(0,game1.remainingKeys);
    }

    @Test
    public void debuffTest() {
        Board board1 = new Board(testmap1);
        Game game1 = new Game(board1);
        game1.movePlayer("S");
        Assertions.assertEquals(-100,game1.score);
    }

    @Test
    public void wallTest() {
        Board board1 = new Board(testmap1);
        Game game1 = new Game(board1);
        game1.movePlayer("W");
        Assertions.assertEquals(4,game1.cPos);
    }

    @Test
    public void rewardTest() {
        Board board1 = new Board(testmap1);
        Game game1 = new Game(board1);
        game1.movePlayer("A");
        Assertions.assertEquals(50,game1.score);
    }

    @Test
    public void enemyTest() {
        Board board1 = new Board(enemymap);
        Game game1 = new Game(board1);
        game1.movePlayer("D");
        Assertions.assertEquals(true,game1.gameEnded);
    }

    @Test
    public void lockTest() {
        Board board1 = new Board(lockmap);
        Game game1 = new Game(board1);
        game1.movePlayer("D");
        Assertions.assertEquals(false,game1.gameEnded);
        Assertions.assertEquals(false,game1.reachedEnd);
    }
    @Test
    public void removedlockTest() {
        Board board1 = new Board(winmap);
        Game game1 = new Game(board1);
        game1.movePlayer("S");
        game1.movePlayer("D");
        game1.gameBoard.print();
        Assertions.assertEquals(true,game1.gameEnded);
        Assertions.assertEquals(true,game1.reachedEnd);
    }

    @Test
    public void emptyTest() {
        Board board1 = new Board(emptymap);
        Game game1 = new Game(board1);
        game1.movePlayer("D");
        Assertions.assertEquals(5,game1.cPos);
    }

    @Test
    public void testMovement(){
        String[][] initialMap = {
                {"W","W","W","W","W","W","W"},
                {"W","M","R","W","R","R","W"},
                {"W","R","E","E","E","R","L"},
                {"W","W","E","W","E","W","W"},
                {"W","K","E","E","K","R","W"},
                {"S","E","R","W","R","R","W"},
                {"W","W","W","W","W","W","W"}
        };

        Board gameBoard = new Board(initialMap);
        gameBoard.print();
        Game game = new Game(gameBoard);
        game.movePlayer("d");
        Assertions.assertEquals(36,game.cPos);
        game.movePlayer("w");
        Assertions.assertEquals(29,game.cPos);
        game.movePlayer("s");
        Assertions.assertEquals(36,game.cPos);
        game.movePlayer("a");
        Assertions.assertEquals(35,game.cPos);
    }

    @Test
    public void testMonsterMovement(){
        String[][] initialMap = {
                {"W", "W", "W", "W", "W"},
                {"S", "M", "E", "M", "W"},
                {"W", "E", "W", "E", "W"},
                {"W", "M", "E", "M", "L"},
                {"W", "W", "W", "W", "W"}
        };

        Board gameBoard = new Board(initialMap);
        gameBoard.print();
        Game game = new Game(gameBoard);

        int[] monsterList = game.enemyPosition;

        Arrays.sort(monsterList, 0, 3);

        game.movePlayer("w");

        gameBoard.print();
        Assertions.assertNotEquals(6,  monsterList[0]);
        Assertions.assertNotEquals(8, monsterList[1]);
        Assertions.assertNotEquals(16, monsterList[2]);
        Assertions.assertNotEquals(18, monsterList[3]);
    }
    @Test
    public void testOutOfBounds() {
        String[][] initialMap = {
                {"W", "E", "W"},
                {"E", "S", "E"},
                {"W", "E", "W"},
        };

        Board gameBoard = new Board(initialMap);
        gameBoard.print();
        Game game = new Game(gameBoard);

        game.movePlayer("a");
        game.movePlayer("a");
        Assertions.assertEquals(3, game.cPos);
        game.movePlayer("d");

        game.movePlayer("w");
        game.movePlayer("w");
        Assertions.assertEquals(1, game.cPos);
        game.movePlayer("s");

        game.movePlayer("s");
        game.movePlayer("s");
        Assertions.assertEquals(7, game.cPos);
        game.movePlayer("w");

        game.movePlayer("d");
        game.movePlayer("d");
        Assertions.assertEquals(5, game.cPos);
    }
}
